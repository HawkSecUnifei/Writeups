from ctypes import CDLL
from pwn import *

# Lista de personagens possíveis. Obtidos por meio do Ghidra, a partir do endereço 0x00102008.
heroes = ["Anti-Mage", "Axe", "Bane", "Bloodseeker", "Crystal Maiden", "Drow Ranger", "Earthshaker", "Juggernaut", 
          "Mirana", "Morphling", "Phantom Assassin", "Pudge", "Shadow Fiend", "Sniper", "Storm Spirit", "Sven", "Tiny",
          "Vengeful Spirit", "Windranger", "Zeus"]

elf = context.binary = ELF("./mr_unlucky")
p = remote("ip", "porta")

# Carregando as bibliotecas da libc, e setando o time para o tempo atual - 3 (devido ao sleep no servidor).
# Note que se estiver rodando localmente o processo, o '- 3' não é necessário.
libc = CDLL("libc.so.6")
libc.srand(libc.time(0) - 3)

# Respondendo as perguntas. Com a mesma seed, os elementos gerados serão os mesmos.
p.recvuntil(b"aegis!")
for i in range(0x32):
    index = (libc.rand() % 0x14)
    p.sendlineafter(b"): ", heroes[index].encode())
    print(p.recvline().decode())

print(p.recvall().decode())
# Flag: ENO{0NLY_TH3_W0RTHY_0N35_C4N_CL41M_THE_AEGIS_OF_IMMORTALITY!!!}