import random

def decode_scrambled(scrambled_result, chunk_size=4):
    # Recriando a lista de chunks após o shuffle.
    num_chunks = len(scrambled_result) // chunk_size
    scrambled_chunks = [scrambled_result[i:i+chunk_size] for i in range(0, len(scrambled_result), chunk_size)]
    
    # Testando todas as seeds possíveis.
    for seed in range(11):
        random.seed(seed)
        
        # O shuffle embaralha os elementos da lista. Para revertermos ele, devemos refazer o shuffle mas ao invés de usarmos os
        # elementos, usaremos índices, pois com a mesma seed o resultado do embaralhamento será o mesmo e com isso saberemos qual
        # elemento estava em qual posição.
        indices = list(range(num_chunks))  # Índices originais dos chunks
        random.shuffle(indices)  # Aplicando o shuffle nos índices
        
        # Criando uma lista vazia para os chunks ordenados corretamente.
        reordered_chunks = [None] * num_chunks

        # Reorganizando os chunks na ordem correta.
        for i, shuffled_index in enumerate(indices):
            reordered_chunks[shuffled_index] = scrambled_chunks[i]

        # Juntando os chunks de volta.
        reordered_result = [item for chunk in reordered_chunks for item in chunk]

        # Revertendo o XOR. Para isso é necessário a key utilizada, mas podemos descobrir ela por assumindo que o 4º caractere é '{'.
        key = reordered_result[3] ^ ord('{')
        flag = [reordered_result[i] ^ key for i in range(len(reordered_result))]
        print("".join(chr(b) for b in flag))

    # Flag: ENO{5CR4M83L3D_3GG5_4R3_1ND33D_T45TY!!!}
    return

def main():
    result = "1e78197567121966196e757e1f69781e1e1f7e736d6d1f75196e75191b646e196f6465510b0b0b57"
    
    # Refazendo a scrambled_result, ou seja, convertendo os pares hexadecimais do output.txt para seus valores decimais.
    scrambled_result = [int(result[i:i+2], 16) for i in range(0, len(result), 2)]
    decode_scrambled(scrambled_result)

if __name__ == "__main__":
    main()
