from ctypes import CDLL
from pwn import *

libc = CDLL("libc.so.6")
libc.srand(libc.time(0) - 5)

#p = process("./the-eye")
p = remote("chall.lac.tf", 31313)

flag = p.recvall().decode()
qnt_carac = len(flag) - 1

# Refazendo o shuffle.
index = list(range(qnt_carac))
def shuffle(lista):
    aux = qnt_carac
    for i in range(qnt_carac - 1, -1, -1):
        idx = libc.rand() % aux
        lista[i], lista[idx] = lista[idx], lista[i]
        aux = i

for _ in range(22):
    shuffle(index)

# Montando a flag.
original_flag = [""] * qnt_carac
for i, original in enumerate(index):
    original_flag[original] = flag[i]

print("".join(original_flag))