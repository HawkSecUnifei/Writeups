from ctypes import CDLL
from pwn import *

cookies = [b"Chocolate Chip", b"Sugar Cookie", b"Oatmeal Raisin", b"Peanut Butter", b"Snickerdoodle", b"Shortbread", b"Gingerbread", b"Macaron", b"Macaroon", b"Biscotti", b"Butter Cookie", 
           b"White Chocolate Macadamia Nut", b"Double Chocolate Chip", b"M&M Cookie", b"Lemon Drop Cookie", b"Coconut Cookie", b"Almond Cookie", b"Thumbprint Cookie", b"Fortune Cookie", 
           b"Black and White Cookie", b"Molasses Cookie", b"Pumpkin Cookie", b"Maple Cookie", b"Espresso Cookie", b"Red Velvet Cookie", b"Funfetti Cookie", b"S'mores Cookie", b"Rocky Road Cookie",
           b"Caramel Apple Cookie", b"Banana Bread Cookie", b"Zucchini Cookie", b"Matcha Green Tea Cookie", b"Chai Spice Cookie", b"Lavender Shortbread", b"Earl Grey Tea Cookie", 
           b"Pistachio Cookie", b"Hazelnut Cookie", b"Pecan Sandies", b"Linzer Cookie", b"Spritz Cookie", b"Russian Tea Cake", b"Anzac Biscuit", b"Florentine Cookie", b"Stroopwafel",
           b"Alfajores", b"\x50\x6f\x6c\x76\x6f\x72\xc3\xb3\x6e\x00", b"Springerle", b"\x50\x66\x65\x66\x66\x65\x72\x6e\xc3\xbc\x73\x73\x65\x00", b"Speculoos", b"Kolaczki", b"Rugelach",
           b"Hamantaschen", b"Mandelbrot", b"Koulourakia", b"Melomakarona", b"Kourabiedes", b"Pizzelle", b"Amaretti", b"Cantucci", b"Savoiardi (Ladyfingers)", b"Madeleine", b"Palmier",
           b"Tuile", b"Langue de Chat", b"Viennese Whirls", b"Empire Biscuit", b"Jammie Dodger", b"Digestive Biscuit", b"Hobnob", b"Garibaldi Biscuit", b"Bourbon Biscuit", b"Custard Cream",
           b"Ginger Nut", b"Nice Biscuit", b"Shortcake", b"Jam Thumbprint", b"Coconut Macaroon", b"Chocolate Crinkle", b"Pepparkakor", b"Sandbakelse", b"Krumkake", b"Rosette Cookie",
           b"Pinwheel Cookie", b"Checkerboard Cookie", b"Rainbow Cookie", b"Mexican Wedding Cookie", b"Snowball Cookie", b"Cranberry Orange Cookie", b"Pumpkin Spice Cookie", 
           b"Cinnamon Roll Cookie", b"Chocolate Hazelnut Cookie", b"Salted Caramel Cookie", b"Toffee Crunch Cookie", b"Brownie Cookie", b"Cheesecake Cookie", b"Key Lime Cookie",
           b"Blueberry Lemon Cookie", b"Raspberry Almond Cookie", b"Strawberry Shortcake Cookie", b"Neapolitan Cookie"]

libc = CDLL("libc.so.6")
p = remote("20.244.40.210", 6000)
libc.srand(libc.time(0) - 2)
#p = process("./main")

p.recvuntil(b"the flag!")
for i in range(100):
    num = libc.rand() % 100
    p.sendlineafter(b"Guess the cookie: ", cookies[num])
    print(p.recvline(), cookies[num])

print(p.recvall().decode())
# BITSCTF{7h4nk5_f0r_4ll_0f_th3_c00ki3s_1_r34lly_enjoy3d_th3m_d31fa51e}