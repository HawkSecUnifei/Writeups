#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

char *greetings[] = {
    "Can't believe you made it!!",
    "You have got that fire in you today!",
    "You're here! Let's have some fun!",
    "Ready to embark on an exciting journey?",
    "Buckle up, it's going to be a wild ride!",
    "You're about to enter a world of adventure.",
    "Get ready for an amazing experience!",
    "Welcome, let's get this party started!",
    "Exciting times await, welcome aboard!",
    "Your adventure begins now!",
    "Step into the world of possibilities.",
    "Join the fun and enjoy the ride!",
    "The journey begins with you!",
    "Prepare for a fantastic experience.",
    "Welcome to the world of endless possibilities.",
    "The stage is yours, shine bright!",
    "Time to shine and have some fun!",
    "Embrace the adventure that lies ahead.",
    "You're in for a treat!",
    "The fun starts now!",
};

int main() {

    setvbuf(stdin, NULL, 2, 0);
    setvbuf(stdout, NULL, 2, 0);

    // Read the contents of the "flag.txt" file into a buffer
    FILE *file = fopen("flag.txt", "r");
    if (file == NULL) {
        perror("Error opening file. Perhaps there is no such file as flag.txt in the current directory.\n");
        return 1;
    }

    char buffer[100];
    if (fgets(buffer, sizeof(buffer), file) == NULL) {
        perror("Error reading file\n");
        fclose(file);
        return 1;
    }

    fclose(file);

    // Initialize random number generator
    srand(time(0));

    char userName[9];
    for (int i = 0; i < 7; i++) {

        printf("Enter your name: ");
        fgets(userName, sizeof(userName), stdin);
        userName[strcspn(userName, "\n")] = '\0';
        int randomIndex = rand() % (sizeof(greetings) / sizeof(greetings[0]));

        char message[200];
        snprintf(message, sizeof(message), "Welcome %s! %s\n", userName, greetings[randomIndex]);

        printf(message);

    }

    return 0;
}